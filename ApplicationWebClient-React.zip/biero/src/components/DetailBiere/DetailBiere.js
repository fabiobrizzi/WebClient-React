import React from "react";
import { renderMatches, useParams } from "react-router-dom";
import { useState, useEffect } from "react";
import { FaStar } from "react-icons/fa";
import defaultImage from './biero-bouteil.svg';

import Button from 'react-bootstrap/Button';
import Card from 'react-bootstrap/Card';


export default function DetailBiere(props) {
    
    // Rating System
    const colors = {
        orange: "#FFBA5A",
        grey: "#a9a9a9"
        
    };
    const [currentValue, setCurrentValue] = useState(0);
    const [hoverValue, setHoverValue] = useState(undefined);
    const stars = Array(5).fill(0)

    const handleClick = value => {
        setCurrentValue(value)
    }

    const handleMouseOver = newHoverValue => {
        setHoverValue(newHoverValue)
    };

    const handleMouseLeave = () => {
        setHoverValue(undefined)
    }
    
    // Get the id from the url
    const params = useParams();
    //console.log(params);

    const   urlBiere = `http://127.0.0.1:8000/webservice/php/biere/${params.id}`,
    //console.log(urlBiere);
            // Pour obtenir les commentaire de la bieres
            urlBiereCommentaire = `${urlBiere}/commentaire`,
            // Pour obtenir les notes de la bieres
            urlBiereNote = `${urlBiere}/note`;
            //Dont forget to use parseInt() to convert the string to a number
            //console.log(urlBiereNote);
            //console.log(urlBiereCommentaire);

    const   [biere, setBiere] = useState({}),
            [commentaires, setCommentaires] = useState([]),
            [note, setNote] = useState({}),
            [nouveauCommentaire, setNouveauCommentaire] = useState(""),
            [nouveauNote, setNouveauNote] = useState("");

    const styles = {
                container: {
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center"
                },
                stars: {
                  display: "flex",
                  flexDirection: "row",
                },
                textarea: {
                  border: "1px solid #a9a9a9",
                  borderRadius: 5,
                  padding: 10,
                  margin: "20px 0",
                  minHeight: 100,
                  width: 300
                },
                button: {
                  border: "1px solid #a9a9a9",
                  borderRadius: 5,
                  width: 300,
                  padding: 10,
                }
              
              };

    useEffect(() => {
        //Apelle fetch sur la ressource
        fetch(urlBiere)
        // Récupération de la réponse en format JSON data des bieres 
            .then((response) => {return response.json() })
            .then((data) => {
                //console.log('URLBIERE');
                //console.log(data.data);
                setBiere(data.data);

                //let bieres = data.data;
                //console.log(bieres);
                //console.log(bieres.image);
                
            })

        // Récupération de la réponse en format JSON des commentaires
        fetch(urlBiereCommentaire)
            .then((response) => {return response.json() })
            .then((data) => {
                //console.log(data.data);
                setCommentaires(data.data);
            })
        // Récupération de la réponse en format JSON des notes
        fetch (urlBiereNote)
            .then((response) => {return response.json() })
            .then((data) => {
                //console.log(data.data);
                //console.log('URLBIERENOTE');
                //console.log(data.data.note);
                data.data.note = parseInt(data.data.note).toFixed(0);  
                //console.log(data.data.note);
                //setNote(data.data.note);
                setNote(data.data);
            })
            
    }, []); // On met un array vide pour eviter le loop infini
   
        
    
    // Section pour recuperer les commentaires
    const commentairesDom = commentaires.map((commentaire, index) => {
        //console.log(commentaire);
        return <p key={index}>{commentaire.commentaire} <small>{commentaire.courriel}</small></p>
    })


    //Setion pour recuperer les notes
    const noteDom = 
                    <div>
                        <p>Note : {note.note}</p> <p><small>Nombre : ({note.nombre})</small></p>
                    </div>
    
  
    


    // Section pour recuperer les notes ! 
    // A COMPLETER
    //PAs oublier de faire un parseInt pour convertir le string en number
    //const notesDom = notes.map((note, index) => { //// A COMPLETER
   
    
    let blockAjoutCommentaire,
        blockAjoutNote;
     
    if (props.courriel) {
        console.log('usager est log')

        blockAjoutCommentaire =     
                                    <div style={styles.container}>
                                        {/* <h3>Ajouter un commentaire</h3>
                                        <textarea onBlur={setCommentaire} placeholder="Ajoutez votre commentaire" style={styles.textarea}/>
                                
                                        <button onClick={soumettreCommentaire} style={styles.button}>Soummetre</button> */}

                                    <Card>
                                    <Card.Header>{biere.brasserie}</Card.Header>
                                        <Card.Body>
                                            <Card.Title>Ajouter votre commentaire</Card.Title>
                                            <br></br>
                                            <textarea onBlur={setCommentaire} placeholder="Ajoutez votre commentaire" style={styles.textarea}/>
                                            <button onClick={soumettreCommentaire} style={styles.button}>Soummetre</button>
                                        </Card.Body>
                                    </Card>
                                    </div>
        // Ajout de la note BlockAjoutNote
        blockAjoutNote =                
                                            <div style={styles.container}>
                                            <h3>Ajouter une Note</h3>
                                            <input onBlur={setNote} placeholder="Ajoutez votre note" style={styles.input}/>

                                            <button onClick={soumettreNote} style={styles.button}>Soummetre</button>
                                        
                                        </div>
                                    // <div>

                                    //         <h2>Ajoutez votre note</h2>
                                    //         <input onBlur={setNote} type="number" min="0" max="5" placeholder="Ajouter Votre Note"></input>
                                    //         <button onClick={soumettreNote}>Soummetre</button>

                                    //     {/* <h2> Ajouter Votre Note </h2> */}
                                    //     {/* <div style={styles.stars}>
                                    //     {stars.map((_, index) => {
                                    //         return (
                                    //         <FaStar
                                    //             key={index}
                                    //             size={24}
                                    //             onBlur={(setNote) => handleClick(index + 1)}
                                    //             onMouseOver={() => handleMouseOver(index + 1)}
                                    //             onMouseLeave={handleMouseLeave}
                                    //             color={(hoverValue || currentValue) > index ? colors.orange : colors.grey}
                                    //             style={{
                                    //             marginRight: 10,
                                    //             cursor: "pointer"
                                    //             }}
                                    //         />
                                    //         )
                                    //     })}
                                    //     </div>                   */}
                                    // </div>
                                    
    }

    //Section Commentaire
    function setCommentaire (e){
        //console.log('setCommentaire');
        console.log(e.target.value);
    }

    async function soumettreCommentaire (e){

        console.log('soumettreCommentaire');

       let  oCommentaire = {
            commentaire: nouveauCommentaire,
            courriel: props.courriel,
       }

       let options = {
            method: 'PUT',
            headers: {  
                'Content-Type': 'application/json',
                'Authorization': 'Basic ' + btoa('biero:biero')
            },
            body: JSON.stringify(oCommentaire)
        }
        let putCommentaire = await fetch(urlBiereCommentaire, options),
            getCommentaires = await fetch(urlBiereCommentaire);
        
        Promise.all ([putCommentaire, getCommentaires])
            .then((response) => {
                return response[1].json();
            })
            .then((data) => {
                setCommentaires(data.data);
            })
    }
    async function soumettreNote (e){

        console.log('soumettreNote');

       let  oNote = {
            note: nouveauNote,
            courriel: props.courriel,
       }

       let options = {
            method: 'PUT',
            headers: {  
                'Content-Type': 'application/json',
                'Authorization': 'Basic ' + btoa('biero:biero')
            },
            body: JSON.stringify(oNote)
        }
        let putNote = await fetch(urlBiereNote, options),
            getNote = await fetch(urlBiereNote);
        
        Promise.all ([putNote, getNote])
            .then((response) => {
                return response[1].json();
            })
            .then((data) => {
                setNote(data.data);
            })
    }
    


    /*
            reparer lerreur opertional chaining ? sur biere?.nom pour mesure de securité  
            Manque {blocAjoutCommentaire} et {blockAjoutNote}
    
    */
          

    return(

        
        <div style={styles.container}>

        <article>
            <div className="p-4">
                <Card>
                <Card.Header>{biere.brasserie}</Card.Header>
                    <Card.Body>
                        <Card.Title>{biere.nom}</Card.Title>
                        <br></br>
                        <h3>Description</h3>
                        <Card.Text>
                        {biere.description}
                        </Card.Text>
                    </Card.Body>
                </Card>
                <Card>

                <Card.Header>Commentaire</Card.Header>
                    <Card.Body>
                        <br></br>
                        <Card.Text>
                        {commentairesDom}                        
                        </Card.Text>
                        <Card.Header>Note</Card.Header>
                        <Card.Text>
                        {noteDom}
                        </Card.Text>
                    </Card.Body>
                </Card>
                
            </div>
            {blockAjoutCommentaire}
            {blockAjoutNote}
            
        </article>
        </div>
    )

}
