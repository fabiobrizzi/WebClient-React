import React from "react";
import { Link } from "react-router-dom";
import './ListeBiere.css';
import Biere from '../Biere/Biere';


export default class ListeBiere extends React.Component {

  constructor(props){
    super(props);
    this.state = {
      biere : []
    }

  }

  componentDidMount() {
    
    //console.log("componentDidMount");
    //Fetch API pour aller chercher les biere
    fetch("http://127.0.0.1:8000/webservice/php/biere/")
      .then((response) => {
        if (response.ok) return response.json();
        else throw new Error("Erreur de connexion")
      })
      .then ((data) => { 
        //console.log(data.nom);
        this.setState({biere: data.data});
        //console.log(this.state.biere);
      })
      .catch((error) => {
        //console.log(error);
      })
   
  }


  
    
  render() {  
    //On Boucle avec map pour afficher les biere
    const bieres = this.state.biere.map((biere, index) => {
      return <Link style={{textDecoration:'none'}} to={`/biere/${biere.id_biere}`} key={index}><Biere data={biere}/></Link>
    });

    return (
      <div className="grid">
        {bieres}
      </div>
    );
  }
}