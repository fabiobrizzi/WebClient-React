//import logo from './logo.svg';
import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Entete from '../Entete/Entete';
//import Compteur from '../Compteur/Compteur';
import Acceuil from '../Acceuil/Acceuil';
import ListeBiere from '../ListeBiere/ListeBiere';
import DetailBiere from '../DetailBiere/DetailBiere';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';

//import NavBar from '../NavBar/NavBar';
import { NavBar } from '../NavBar/NavBar';



export default class App extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
      courriel: ""
    }
  }
  // Faire passer cette methode dans ENTETE
  //State recu de DetailBiere pour ensuite le faire passer a notre APP en bas CHILD
  login = (courriel) => {
    console.log('login app');
    console.log(courriel);
    this.setState({courriel: courriel});
  }

 /* constructor(props){
    super(props);
    this.state = {
        valeur : 0
        //valeur: parseInt(this.props.valeurInitial) || 0
    }
    // Pour enlever le bind dans le constructor on utilise une arrow function pour Incremente
    //this.incremente = this.incremente.bind(this);
  }
  */
/*
  //Bouton qui va incrementer la valeur de 1
    incremente = () => {
        console.log('incremente');    
        
        // Maniere non flecher
        // this.setState({valeur: ++this.state.valeur}); 
        
        
        // Maniere flecher
        this.setState((state) => ({ valeur : state.valeur + 1 }));
    }
*/


  render() {  
    return (

      <>      
        <Router>
      
            <Entete handleLogin={this.login} />
            {/* Routing system  */}
            <Routes>
              <Route path="/" element={<Acceuil />} />
              {/*<Route path="/compteur" element={<Compteur handleIncremente={this.incremente} valeur={this.state.valeur}  />} /> */}
              <Route path="/liste" element={<ListeBiere />} />
              {/* On passe la methode state courriel sur DetailBiere */}
              <Route path="/biere/:id" element={<DetailBiere courriel={this.state.courriel} />} />
              
              <Route path="*" element={<Acceuil  />} />

            </Routes>
          
        </Router>
      </>
    );
  }
}


/*

  -MISE EN PAGE DE L'ENTETE AVEC UN LOGO SVG
  -MISE EN PAGE DE L'ACCUEIL AVEC DU CONTENU STRATIQUE (HTML) INRODUCTION
  -MISE EN PAGE DE LA GRILLE DE LISTE BIERE
  -MISE EN PAGE DE LA TUILE IMAGE NOM ET BRASSERIE (CARTE BIERE) ET GESTION DE L'IMAGE PAR DEFAUT
  -MISE EN PAGE DE DETAIL BIERE IMAGE NOM BRASSERIE ET DESCRIPTION COMMENTAIRE ET GESTION DE L'IMAGE PAR DEFAUT
  -GESTION DYNAMIQUE DE LA NOTE ACTUEL 
  -GESTION MISE EN PAGE AJOUT COMMENTAIRE
  -NOUVEAU BLOC AJOUT NOTE + SA MISE EN PAGE





*/
