import React from "react";

//import { Link } from "react-router-dom";
import {NavLink} from 'react-router-dom';
//Boostrap import
import { Col, Row, Navbar, Nav,  Container,Image, NavDriopDown,  NavItem, Cards } from "react-bootstrap";
import logoNavBar from '../../assets/img/biero_logo.svg';


export const NavBar = () => {
    return (
      <>
    <Navbar bg="dark" variant="dark" expand="lg">
      <Container>
        <Navbar.Brand className="px-4 my-2 " href="#home"> 
        Biero 
        <NavLink to="/liste">
        <Image className="px-3" src={logoNavBar}  alt="logo"/>
        </NavLink>

        </Navbar.Brand>
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav">
          <Nav className=" px-4 my-4 flex-grow-1 ">
            <NavLink className=' mx-5' style={{textDecoration:'none'}} to="/">Accueil</NavLink>
            <NavLink  style={{textDecoration:'none'}} to="/liste">Liste des bieres</NavLink>
          </Nav>
          
        </Navbar.Collapse>
      </Container>
    </Navbar>

    </>
  );
}

