
import React from 'react';

// Section BootStrap
import { Card,Col, Row, Navbar, Nav,  Container,Image, NavDriopDown,  NavItem, Cards, Button } from "react-bootstrap";
//Import des images
import logoImg from '../../assets/img/biero_logo.svg';
import backgroundImg from '../../assets/img/biero_wallpaper.jpeg';
import {NavLink, Link} from 'react-router-dom';

import './Acceuil.css';


export default class Acceuil extends React.Component {
    
  render() {  
    return (
     <>
       <main>
          <Container className='acceuil-hero'>
            <Row className='px-1 my-2'>
              <Col sm={7}>
                <Image src="https://placebeer.com/900/768" alt="biero-hero" fluid rounded />
              </Col>
              <Col sm={5}> 
                <h1>Microbrasserie des artisants</h1>
                <p>Découvrez les meilleures bières artisanales de tout le pays. 
                  Avis d'experts fiables par des personnes qui aiment et connaissent la bière.
                </p>
               
                <nav>
                <NavLink to="/liste">
                  <Button variant="warning" size="lg">Découvrez nos bières
                  </Button>
                  </NavLink>
                </nav>
              </Col>
            </Row>
            
          </Container>
       </main>
     </>
    );
  }
}