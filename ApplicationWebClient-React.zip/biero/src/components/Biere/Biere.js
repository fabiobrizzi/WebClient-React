import React from "react";
import './Biere.css';
import { Card , Button, Row, Col} from 'react-bootstrap';
import cardImage from '../../assets/img/biero-bouteil.svg';




//faire un console log pour this.props.nom
export default class Biere extends React.Component {

    
    render(){
        //Il faut passer par la clef(prop) data pour aller chercher les donnees du tableau de ListeBiere.js
        // return <Link to={`/biere/${biere.id_biere}`} key={index}><Biere data={biere}/> </Link>

        //console.log(this.props.data.nom)

        return (
            <>
            <Card className="border-0" style={{ width: '18rem' }}>
                <Card.Img className="mx-auto" variant="top" src={cardImage} style={{ height: '20rem' }}/>
                <Card.Body>
                    <Card.Title>{this.props.data.nom}</Card.Title>
                    <Card.Text className="">
                    {this.props.data.brasserie}                    
                    </Card.Text>
                    <Button variant="warning">En savoir plus</Button>
                </Card.Body>
                </Card>
            </>     
        );
    }


}