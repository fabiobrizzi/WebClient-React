import React from "react";
import "./Entete.css";
//import BoutonNav from '../BoutonNav/BoutonNav';
import {NavLink} from 'react-router-dom';
import { Col, Row, Navbar, Nav,  Container,Image, NavDriopDown,  NavItem, Cards } from "react-bootstrap";
import logoNavBar from '../../assets/img/biero_logo.svg';




export default class Entete extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      courriel: ""
    }
  }
    // Section Pour Login
    changeCourriel = (e) => {
        //console.log("changeCourriel"); 
        //On recupere la valeur du courriel
        this.setState({courriel: e.target.value});
    }

    login = (e) => {
        e.preventDefault();
        console.log("login entete");
        //Validation du courriel
        if(this.state.courriel !== "") {
      // On recupe la fonction login du parent Ceci attend le couriel
        this.props.handleLogin(this.state.courriel);
      }
    }

    render() {  
      return (
        <header>
            {/*<h1>{this.state.titre} </h1>
                <ul>
                    <li><BoutonNav lien={this.state.titre} label={this.state.titre}/></li>
                    <li><BoutonNav lien="#2" label="Item 2"/></li>
                    <li><BoutonNav lien="#3" label="Item 3"/></li>
                    <NavLink to="/compteur">Compteur</NavLink>
                </ul>
            */}
          <nav>
            {/* <div className="flex">
              <div className='sidebar'>SIDEBAR</div>
                <div className="p-7 text-2xl font-semibold">
                  <NavLink to="/">Accueil</NavLink>
                  <NavLink to="/liste">Liste des bieres</NavLink>
                </div>
            </div> */}
            <Navbar bg="dark" variant="dark" expand="lg">
      <Container>
        <Navbar.Brand className="px-4 my-2 " href="#home"> 
        Biero 
        <NavLink to="/">
        <Image className="px-3" src={logoNavBar}  alt="logo"/>
        </NavLink>

        </Navbar.Brand>
        <Navbar.Toggle aria-controls="basic-navbar-nav" />
        <Navbar.Collapse id="basic-navbar-nav">
          <Nav className=" px-4 my-4 flex-grow-1 ">
            <NavLink className=' mx-5' style={{textDecoration:'none', color:'orange'}} to="/">Accueil</NavLink>
            <NavLink  style={{textDecoration:'none', color:'orange'}} to="/liste">Liste des bieres</NavLink>
          </Nav>
          <div className="login">
              {/* Section Pour Login */}
              <form action="">
                <input onBlur={this.changeCourriel} type="text" placeholder="Usager"></input>
                <button onClick={this.login}>Login</button>
              </form>
            </div>
        </Navbar.Collapse>
      </Container>
    </Navbar>

            
          </nav>
        </header>
      );
    }
  }
  