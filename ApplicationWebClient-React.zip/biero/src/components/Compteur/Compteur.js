import React from 'react';
import './Compteur.css';

export default class Compteur extends React.Component {
    

    

    render() {
        return (
            <div>
                <h1>Compteur</h1>
                <p>{this.props.valeur}</p>
                <button onClick={this.props.handleIncremente}>Incremente</button>
            </div>
        );
    }

}